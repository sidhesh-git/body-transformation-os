BODY TRANSFORMATION OS: SETUP GUIDE (Phase 1, version 1.0.0)
=============================================================

Your data is stored only in Chrome on the device you use.
Nothing is uploaded anywhere. GitHub only hosts the app's code.


1. PUT THE APP ONLINE (one time, on a computer, about 10 minutes)
-----------------------------------------------------------------
 a. Unzip body-transformation-os.zip. You get a folder containing:
      index.html, manifest.json, service-worker.js, README.txt,
      and the folders css, fonts, icons, js.

 b. Go to github.com and sign in.
    Click the "+" (top right) > "New repository".
      Repository name: body-transformation-os
      Visibility: Public   (required for free GitHub Pages; your data is NOT in it)
    Click "Create repository".

 c. On the new, empty repository page, click the link
    "uploading an existing file".

 d. Open the unzipped folder, select EVERYTHING INSIDE it
    (the files and the 4 folders), and drag it all onto the GitHub page.
    Important: drag the contents, not the outer folder itself.
    Wait until every file is listed, then click "Commit changes".

 e. In the repository click "Settings" > "Pages" (left menu).
      Source: Deploy from a branch
      Branch: main    Folder: / (root)
    Click "Save". Wait 1–2 minutes and refresh the page.
    Your address appears at the top, like:
      https://YOUR-USERNAME.github.io/body-transformation-os/


2. INSTALL ON YOUR ANDROID PHONE
--------------------------------
 a. Open the address above in Google Chrome on your phone.
 b. Tap the three-dot menu (top right).
 c. Tap "Add to Home screen" or "Install app", then "Install".
 d. Open Body OS from your home screen from now on.
    The installed app and Chrome share the same data.


3. ADD TO NOTION
----------------
 a. In the app go to Settings > "Home screen and Notion" and tap
    "Copy link" next to the screen you want.
 b. In Notion, paste the link and choose:
      "Create bookmark"  (recommended: tapping opens the app), or
      "Create embed"     (shows a small launcher with buttons)
 c. The embed shows buttons instead of your data. That's on purpose:
    Chrome keeps embedded storage separate, so an embedded copy
    would be empty. The buttons open the real app with your data.
 d. On Android, if a Notion link opens inside Notion, use the menu
    to "Open in Chrome", or just use the home-screen icon.


4. INSTALLING FUTURE PHASES (UPDATES)
-------------------------------------
 a. Unzip the new version.
 b. In your GitHub repository click "Add file" > "Upload files".
 c. Drag in everything from the new folder and click "Commit changes".
    Files with the same name are replaced. Your data is not affected
    (it lives on your phone, not on GitHub).
 d. Wait 1–2 minutes, then open the app. A banner appears:
    "A new version of the app is ready" > tap "Update now".
    Or: Settings > "Check for updates".


5. BACKUPS (IMPORTANT)
----------------------
 - Settings > "Download backup" saves a .json file.
 - Settings > "Share backup to Drive or email" sends it straight to
   Google Drive (if your phone supports it).
 - Settings > "Import backup" restores it:
     Merge   = add the backup to what's already there
     Replace = delete current data, then restore the backup exactly
 - The app reminds you if you haven't backed up in 7 days.
 - Clearing Chrome's "site data" or uninstalling Chrome deletes
   the app's data. Keep backups.


6. PREVIEW WITHOUT GITHUB (optional)
------------------------------------
 Double-clicking index.html on a computer opens a preview.
 Offline mode and installing only work on the GitHub Pages address.


7. FILES (what each one does)
-----------------------------
 index.html            the page itself
 manifest.json         makes it installable (name, icon, colours)
 service-worker.js     makes it work offline; holds the version number
 css/                  the look (colours, layout, buttons)
 fonts/                the number font (Barlow Condensed, free licence)
 icons/                the app icon
 js/core/              the engine: database, settings, navigation
 js/features/          the screens: dashboard, settings, backup


Privacy: no accounts, no trackers, no ads, no external servers.
