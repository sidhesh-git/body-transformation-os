/*
 * settings-store.js: your preferences (units, targets, theme, cards).
 * Saved in the database under meta → "settings".
 * New settings in future versions get sensible defaults automatically.
 */
App.settings = (function () {
  const DASHBOARD_CARDS = [
    { id: 'today',    name: 'Today' },
    { id: 'week',     name: 'This week' },
    { id: 'strength', name: 'Strength trend' },
    { id: 'body',     name: 'Body trend' },
    { id: 'quick',    name: 'Quick actions' }
  ];

  const DEFAULTS = {
    weightUnit: 'kg',        // 'kg' | 'lb'
    lengthUnit: 'cm',        // 'cm' | 'in'
    distanceUnit: 'km',      // 'km' | 'mi'
    weekStart: 1,            // 1 = Monday, 0 = Sunday
    theme: 'system',         // 'system' | 'light' | 'dark'
    targets: {
      kcal: 2300,
      protein: 160,
      carbs: 250,
      fat: 75,
      fiber: 30,
      waterMl: 3000,
      steps: 10000,
      sleepHours: 7.5
    },
    maintenanceKcal: null,   // estimate, entered by you
    goalWeightKg: null,
    dashboardCards: DASHBOARD_CARDS.map((c) => ({ id: c.id, visible: true }))
  };

  let current = App.util.clone(DEFAULTS);
  const listeners = [];

  /** Keep saved card order, drop unknown cards, add any new ones at the end */
  function normaliseCards(list) {
    const known = DASHBOARD_CARDS.map((c) => c.id);
    const seen = new Set();
    const out = [];
    (Array.isArray(list) ? list : []).forEach((c) => {
      if (c && known.includes(c.id) && !seen.has(c.id)) {
        seen.add(c.id);
        out.push({ id: c.id, visible: c.visible !== false });
      }
    });
    known.forEach((id) => { if (!seen.has(id)) out.push({ id, visible: true }); });
    return out;
  }

  function sanitise(raw) {
    const s = App.util.mergeDefaults(DEFAULTS, raw);
    if (!['kg', 'lb'].includes(s.weightUnit)) s.weightUnit = 'kg';
    if (!['cm', 'in'].includes(s.lengthUnit)) s.lengthUnit = 'cm';
    if (!['km', 'mi'].includes(s.distanceUnit)) s.distanceUnit = 'km';
    if (![0, 1].includes(s.weekStart)) s.weekStart = 1;
    if (!['system', 'light', 'dark'].includes(s.theme)) s.theme = 'system';
    for (const k of Object.keys(DEFAULTS.targets)) {
      if (!Number.isFinite(s.targets[k]) || s.targets[k] <= 0) s.targets[k] = DEFAULTS.targets[k];
    }
    s.dashboardCards = normaliseCards(s.dashboardCards);
    return s;
  }

  async function load() {
    const saved = await App.db.getMeta('settings');
    current = sanitise(saved);
    applyTheme();
    return current;
  }

  function get() { return current; }

  /** Change settings. `patch` can be partial, e.g. { targets: { protein: 170 } } */
  async function update(patch) {
    const next = App.util.clone(current);
    for (const [k, v] of Object.entries(patch)) {
      if (App.util.isObj(v) && App.util.isObj(next[k])) Object.assign(next[k], v);
      else next[k] = v;
    }
    current = sanitise(next);
    await App.db.setMeta('settings', current);
    applyTheme();
    listeners.forEach((fn) => { try { fn(current); } catch (e) { console.error(e); } });
    return current;
  }

  function onChange(fn) { listeners.push(fn); }

  function applyTheme() {
    const root = document.documentElement;
    if (current.theme === 'light' || current.theme === 'dark') root.setAttribute('data-theme', current.theme);
    else root.removeAttribute('data-theme');
    try { localStorage.setItem('btos-theme', current.theme); } catch (e) {}
    const dark = current.theme === 'dark' ||
      (current.theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
    document.querySelectorAll('meta[name="theme-color"]').forEach((m) => {
      m.setAttribute('content', dark ? '#17212B' : '#EEF0EC');
      m.removeAttribute('media');
    });
  }

  return { DEFAULTS, DASHBOARD_CARDS, load, get, update, onChange, sanitise, applyTheme };
})();
