/*
 * router.js: switches screens based on the address, e.g.
 *   .../#/dashboard   .../#/workout   .../#/nutrition?add=food
 * These addresses are stable, so you can link to them from Notion.
 */
App.router = (function () {
  const routes = new Map();
  const DEFAULT = 'dashboard';
  let renderToken = 0;
  let current = null;

  /** register('workout', { title: 'Workout', render: async (el, params) => {} }) */
  function register(name, def) { routes.set(name, def); }
  function has(name) { return routes.has(name); }

  function parse() {
    const raw = (location.hash || '').replace(/^#\/?/, '');
    const [path, query] = raw.split('?');
    const name = (path || '').split('/')[0] || DEFAULT;
    const params = {};
    new URLSearchParams(query || '').forEach((v, k) => { params[k] = v; });
    return { name, params };
  }

  function go(name, params) {
    const q = params ? '?' + new URLSearchParams(params).toString() : '';
    const target = '#/' + name + q;
    if (location.hash === target) render();
    else location.hash = target;
  }

  /** Re-draw the current screen (e.g. after data changes) */
  function refresh() { return render(true); }

  async function render(keepScroll) {
    let { name, params } = parse();
    if (!routes.has(name)) {
      name = DEFAULT;
      history.replaceState(null, '', '#/' + DEFAULT);
    }
    const def = routes.get(name);
    const token = ++renderToken;
    const view = document.getElementById('view');
    const changed = current !== name;
    current = name;

    document.querySelectorAll('.nav-link').forEach((a) => {
      if (a.dataset.route === name) a.setAttribute('aria-current', 'page');
      else a.removeAttribute('aria-current');
    });
    App.ui.setTitle(def.title);

    try {
      // Each screen draws into its own container, which is then swapped in whole.
      // Screens should look up their elements with el.querySelector(...).
      const page = document.createElement('div');
      page.className = 'view-page';
      page.dataset.route = name;
      await def.render(page, params);
      if (token !== renderToken) return; // user already moved to another screen
      view.replaceChildren(page);
      if (changed && !keepScroll) {
        window.scrollTo(0, 0);
        view.focus({ preventScroll: true });
      }
    } catch (err) {
      console.error(err);
      if (token !== renderToken) return;
      view.innerHTML = App.ui.empty({
        title: 'This screen could not load',
        text: 'Your data is safe. Reload the app. If this keeps happening, export a backup from Settings.',
        actionHtml: '<button class="btn btn-primary" type="button" onclick="location.reload()">Reload</button>'
      });
    }
  }

  function start() {
    window.addEventListener('hashchange', () => render());
    if (!location.hash) history.replaceState(null, '', '#/' + DEFAULT);
    return render();
  }

  return { register, has, go, refresh, start, parse, get current() { return current; } };
})();
