/*
 * dates.js: all dates are stored as local "YYYY-MM-DD" text.
 * This avoids midnight/time-zone bugs (a meal at 11:30 pm stays on that day).
 */
App.dates = (function () {
  const pad = (n) => String(n).padStart(2, '0');
  const KEY_RE = /^\d{4}-\d{2}-\d{2}$/;

  function toKey(d) {
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate());
  }
  function fromKey(key) {
    const [y, m, d] = key.split('-').map(Number);
    return new Date(y, m - 1, d, 12); // midday avoids daylight-saving edge cases
  }
  function isKey(v) {
    if (typeof v !== 'string' || !KEY_RE.test(v)) return false;
    const d = fromKey(v);
    return toKey(d) === v;
  }
  function today() { return toKey(new Date()); }
  function addDays(key, n) {
    const d = fromKey(key);
    d.setDate(d.getDate() + n);
    return toKey(d);
  }
  function diffDays(a, b) { // b - a, in days
    return Math.round((fromKey(b) - fromKey(a)) / 86400000);
  }
  /** First day of the week containing `key`. weekStart: 1 = Monday, 0 = Sunday */
  function weekStartOf(key, weekStart) {
    const d = fromKey(key);
    const ws = weekStart === 0 ? 0 : 1;
    const shift = (d.getDay() - ws + 7) % 7;
    d.setDate(d.getDate() - shift);
    return toKey(d);
  }
  /** List of keys from start to end inclusive */
  function range(start, end) {
    const out = [];
    let k = start;
    let guard = 0;
    while (k <= end && guard++ < 4000) { out.push(k); k = addDays(k, 1); }
    return out;
  }
  function formatLong(key) {
    return fromKey(key).toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' });
  }
  function formatShort(key) {
    return fromKey(key).toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
  }
  function formatWithYear(key) {
    return fromKey(key).toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
  }

  return { toKey, fromKey, isKey, today, addDays, diffDays, weekStartOf, range, formatLong, formatShort, formatWithYear };
})();
