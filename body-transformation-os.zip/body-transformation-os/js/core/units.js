/*
 * units.js: everything is SAVED in metric (kg, cm, km, ml).
 * Conversion happens only when showing numbers on screen,
 * so switching units never changes your stored data.
 */
App.units = (function () {
  const KG_PER_LB = 0.45359237;
  const CM_PER_IN = 2.54;
  const KM_PER_MI = 1.609344;

  const s = () => (App.settings ? App.settings.get() : { weightUnit: 'kg', lengthUnit: 'cm', distanceUnit: 'km' });

  // ----- weight -----
  function weightUnit() { return s().weightUnit === 'lb' ? 'lb' : 'kg'; }
  function kgToDisplay(kg) { return weightUnit() === 'lb' ? kg / KG_PER_LB : kg; }
  function displayToKg(v) { return weightUnit() === 'lb' ? v * KG_PER_LB : v; }
  function formatWeight(kg, dp) {
    if (!Number.isFinite(kg)) return '—';
    return App.util.fmt(kgToDisplay(kg), dp == null ? 1 : dp);
  }

  // ----- length -----
  function lengthUnit() { return s().lengthUnit === 'in' ? 'in' : 'cm'; }
  function cmToDisplay(cm) { return lengthUnit() === 'in' ? cm / CM_PER_IN : cm; }
  function displayToCm(v) { return lengthUnit() === 'in' ? v * CM_PER_IN : v; }

  // ----- distance -----
  function distanceUnit() { return s().distanceUnit === 'mi' ? 'mi' : 'km'; }
  function kmToDisplay(km) { return distanceUnit() === 'mi' ? km / KM_PER_MI : km; }
  function displayToKm(v) { return distanceUnit() === 'mi' ? v * KM_PER_MI : v; }

  // ----- water -----
  function formatLitres(ml) {
    if (!Number.isFinite(ml)) return '—';
    return App.util.fmt(ml / 1000, 1);
  }

  /**
   * Read a number typed by the user.
   * Accepts "72.5" and "72,5". Returns { ok, value, error }.
   * opts: { min, max, required, integer, label }
   */
  function parseNum(raw, opts) {
    const o = opts || {};
    const label = o.label || 'This value';
    const text = String(raw == null ? '' : raw).trim().replace(/\s/g, '');
    if (text === '') {
      return o.required ? { ok: false, value: null, error: label + ' is required.' } : { ok: true, value: null };
    }
    let norm = text;
    if (/^-?\d+,\d+$/.test(norm)) norm = norm.replace(',', '.');
    norm = norm.replace(/,/g, '');
    if (!/^-?\d*\.?\d+$/.test(norm)) return { ok: false, value: null, error: label + ' must be a number.' };
    const n = Number(norm);
    if (!Number.isFinite(n)) return { ok: false, value: null, error: label + ' must be a number.' };
    if (o.integer && !Number.isInteger(n)) return { ok: false, value: null, error: label + ' must be a whole number.' };
    if (o.min != null && n < o.min) return { ok: false, value: null, error: label + ' must be at least ' + o.min + '.' };
    if (o.max != null && n > o.max) return { ok: false, value: null, error: label + ' must be ' + o.max + ' or less.' };
    return { ok: true, value: n };
  }

  return {
    weightUnit, kgToDisplay, displayToKg, formatWeight,
    lengthUnit, cmToDisplay, displayToCm,
    distanceUnit, kmToDisplay, displayToKm,
    formatLitres, parseNum
  };
})();
