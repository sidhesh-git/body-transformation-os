/*
 * migrations.js: the "blueprint" of the database.
 *
 * DB_VERSION      = version of the IndexedDB structure (tables + indexes)
 * SCHEMA_VERSION  = version of the data format inside backups
 *
 * RULES FOR FUTURE UPDATES (so your data is never lost):
 *  - Never remove a store or rename a field in place.
 *  - To add a store or index: add it to STORES and bump DB_VERSION.
 *    ensureStores() creates only what's missing; existing data stays.
 *  - To transform data: add a step to DATA_STEPS / IMPORT_STEPS.
 */
App.schema = (function () {
  const DB_NAME = 'body-transformation-os';
  const DB_VERSION = 1;
  const SCHEMA_VERSION = 1;

  /*
   * keyPath : the unique ID field
   * indexes : fields the app can look up quickly
   * dateField : must be a valid YYYY-MM-DD date
   * numbers : fields that must be numbers (or empty)
   */
  const STORES = {
    meta:          { keyPath: 'key', indexes: [] },
    foods:         { keyPath: 'id', indexes: ['name'],
                     numbers: ['servingSize', 'kcal', 'protein', 'carbs', 'fat', 'fiber'] },
    mealTemplates: { keyPath: 'id', indexes: ['name'] },
    foodLog:       { keyPath: 'id', indexes: ['date'], dateField: 'date',
                     numbers: ['qty', 'kcal', 'protein', 'carbs', 'fat', 'fiber'] },
    waterLog:      { keyPath: 'id', indexes: ['date'], dateField: 'date', numbers: ['ml'] },
    exercises:     { keyPath: 'id', indexes: ['name'], numbers: ['weightIncrement'] },
    workouts:      { keyPath: 'id', indexes: ['date'], dateField: 'date', numbers: ['durationMin'] },
    sets:          { keyPath: 'id', indexes: ['workoutId', 'exerciseId', 'date'], dateField: 'date',
                     numbers: ['order', 'weight', 'reps', 'rpe', 'restSec'] },
    bodyLog:       { keyPath: 'id', indexes: ['date'], dateField: 'date',
                     numbers: ['weight', 'waist', 'chest', 'neck', 'shoulders', 'arms', 'hips', 'thighs'] },
    daily:         { keyPath: 'date', indexes: [], dateField: 'date',
                     numbers: ['steps', 'sleepHours', 'sleepQuality', 'energy', 'soreness'] },
    activityLog:   { keyPath: 'id', indexes: ['date'], dateField: 'date',
                     numbers: ['durationMin', 'distanceKm', 'kcalEstimate', 'steps'] },
    goals:         { keyPath: 'id', indexes: ['status'], numbers: ['startValue', 'targetValue'] },
    weeklyReviews: { keyPath: 'id', indexes: ['weekStart'], dateField: 'weekStart' }
  };

  /** Create any missing stores/indexes. Never deletes anything. */
  function ensureStores(db, tx) {
    for (const [name, def] of Object.entries(STORES)) {
      let store;
      if (!db.objectStoreNames.contains(name)) {
        store = db.createObjectStore(name, { keyPath: def.keyPath });
      } else {
        store = tx.objectStore(name);
      }
      for (const idx of def.indexes) {
        if (!store.indexNames.contains(idx)) store.createIndex(idx, idx, { unique: false });
      }
    }
  }

  /* Data transformations run during a database upgrade, keyed by the NEW version.
     Example for the future:
     2: (db, tx) => { ...convert old records... }                          */
  const DATA_STEPS = {};

  function upgrade(db, tx, oldVersion, newVersion) {
    ensureStores(db, tx);
    for (let v = oldVersion + 1; v <= newVersion; v++) {
      if (DATA_STEPS[v]) DATA_STEPS[v](db, tx);
    }
  }

  /* Converts OLD backup files to the current format before importing.
     Keyed by the version being upgraded TO.
     Example: 2: (payload) => { payload.data.newStore = []; return payload; } */
  const IMPORT_STEPS = {};

  function migrateImport(payload) {
    let v = payload.schemaVersion;
    while (v < SCHEMA_VERSION) {
      v += 1;
      if (IMPORT_STEPS[v]) payload = IMPORT_STEPS[v](payload);
      payload.schemaVersion = v;
    }
    return payload;
  }

  return { DB_NAME, DB_VERSION, SCHEMA_VERSION, STORES, upgrade, migrateImport };
})();
