/*
 * app.js: creates the single global "App" object that every other
 * file attaches itself to. Loaded first.
 */
window.App = {
  VERSION: '1.0.0',      // app version (shown in Settings)
  PHASE: 1,              // build phase
  features: {},          // screens register here
  util: {}
};

(function (U) {
  /** Unique ID for records, e.g. "lq3k9x-4f2a1c" */
  U.id = function () {
    const rand = (crypto && crypto.getRandomValues)
      ? Array.from(crypto.getRandomValues(new Uint8Array(4)), (b) => b.toString(16).padStart(2, '0')).join('')
      : Math.random().toString(16).slice(2, 10);
    return Date.now().toString(36) + '-' + rand;
  };

  /** Make text safe to put inside HTML (prevents broken layouts from odd characters) */
  U.esc = function (value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  /** Deep copy of plain data */
  U.clone = function (obj) { return JSON.parse(JSON.stringify(obj)); };

  /** Is this a plain object? */
  U.isObj = function (v) { return v !== null && typeof v === 'object' && !Array.isArray(v); };

  /**
   * Merge saved values over defaults, keeping only known keys and types.
   * New settings added in future versions get their default automatically.
   */
  U.mergeDefaults = function (defaults, saved) {
    if (!U.isObj(saved)) return U.clone(defaults);
    const out = {};
    for (const key of Object.keys(defaults)) {
      const d = defaults[key];
      const s = saved[key];
      if (U.isObj(d)) out[key] = U.mergeDefaults(d, s);
      else if (Array.isArray(d)) out[key] = Array.isArray(s) ? U.clone(s) : U.clone(d);
      else if (s === undefined) out[key] = d;
      else if (d === null) out[key] = (s === null || typeof s === 'number') ? s : null;
      else out[key] = (typeof s === typeof d) ? s : d;
    }
    return out;
  };

  /** Round to n decimals */
  U.round = function (n, dp) {
    const f = Math.pow(10, dp || 0);
    return Math.round(n * f) / f;
  };

  /** Sum a list of numbers, ignoring blanks */
  U.sum = function (list) {
    return list.reduce((a, b) => a + (Number.isFinite(b) ? b : 0), 0);
  };

  /** Average of valid numbers, or null if none */
  U.avg = function (list) {
    const v = list.filter(Number.isFinite);
    return v.length ? v.reduce((a, b) => a + b, 0) / v.length : null;
  };

  /** Format a number with thousands separators */
  U.fmt = function (n, dp) {
    if (!Number.isFinite(n)) return '—';
    return n.toLocaleString(undefined, { minimumFractionDigits: dp || 0, maximumFractionDigits: dp || 0 });
  };

  /** Is the app shown inside another site (e.g. a Notion embed)? */
  U.isEmbedded = function () {
    try { return window.self !== window.top; } catch (e) { return true; }
  };
})(App.util);
