/*
 * db.js: talks to IndexedDB (the database built into Chrome).
 * Every other file uses these simple functions instead of raw IndexedDB.
 */
App.db = (function () {
  const S = App.schema;
  let dbPromise = null;

  const req2p = (req) => new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  const tx2p = (tx) => new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
    tx.onabort = () => reject(tx.error || new Error('The save was cancelled.'));
  });

  function open() {
    if (dbPromise) return dbPromise;
    dbPromise = new Promise((resolve, reject) => {
      if (!('indexedDB' in window)) {
        reject(new Error('This browser cannot store data. Open the app in Google Chrome (not an incognito tab).'));
        return;
      }
      let req;
      try {
        req = indexedDB.open(S.DB_NAME, S.DB_VERSION);
      } catch (e) {
        reject(new Error('Storage is blocked in this browser window. Open the app directly in Chrome.'));
        return;
      }
      req.onupgradeneeded = (event) => {
        try {
          S.upgrade(req.result, req.transaction, event.oldVersion, event.newVersion);
        } catch (e) {
          req.transaction.abort();
          reject(e);
        }
      };
      req.onsuccess = () => {
        const db = req.result;
        // A newer version of the app opened in another tab: step aside safely.
        db.onversionchange = () => {
          db.close();
          dbPromise = null;
          if (App.ui) App.ui.banner('The app was updated in another tab. Reload to continue.', { action: 'Reload', onAction: () => location.reload(), warn: true });
        };
        resolve(db);
      };
      req.onerror = () => reject(req.error || new Error('Could not open the database.'));
      req.onblocked = () => {
        if (App.ui) App.ui.toast('Close other tabs of this app, then reload.', 'error');
      };
    });
    dbPromise.catch(() => { dbPromise = null; });
    return dbPromise;
  }

  function stamp(record) {
    const now = new Date().toISOString();
    const r = Object.assign({}, record);
    if (!r.createdAt) r.createdAt = now;
    r.updatedAt = now;
    return r;
  }

  async function get(store, key) {
    const db = await open();
    return req2p(db.transaction(store).objectStore(store).get(key));
  }

  async function getAll(store) {
    const db = await open();
    return req2p(db.transaction(store).objectStore(store).getAll());
  }

  /** Save one record (creates an id if missing). Returns the saved record. */
  async function put(store, record) {
    const db = await open();
    const def = S.STORES[store];
    let r = stamp(record);
    if (def.keyPath === 'id' && !r.id) r.id = App.util.id();
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).put(r);
    await tx2p(tx);
    return r;
  }

  /** Save many records in one step (all or nothing). */
  async function putMany(store, records) {
    const db = await open();
    const def = S.STORES[store];
    const tx = db.transaction(store, 'readwrite');
    const os = tx.objectStore(store);
    const saved = records.map((rec) => {
      const r = stamp(rec);
      if (def.keyPath === 'id' && !r.id) r.id = App.util.id();
      os.put(r);
      return r;
    });
    await tx2p(tx);
    return saved;
  }

  async function remove(store, key) {
    const db = await open();
    const tx = db.transaction(store, 'readwrite');
    tx.objectStore(store).delete(key);
    await tx2p(tx);
  }

  async function count(store) {
    const db = await open();
    return req2p(db.transaction(store).objectStore(store).count());
  }

  /** All records where index === value */
  async function byIndex(store, index, value) {
    const db = await open();
    return req2p(db.transaction(store).objectStore(store).index(index).getAll(IDBKeyRange.only(value)));
  }

  /** All records where index is between from and to (inclusive) */
  async function byRange(store, index, from, to) {
    const db = await open();
    const os = db.transaction(store).objectStore(store);
    const range = IDBKeyRange.bound(from, to);
    return req2p(index ? os.index(index).getAll(range) : os.getAll(range));
  }

  /** Records for one date (store must have a date field) */
  function byDate(store, dateKey) {
    const def = S.STORES[store];
    if (def.keyPath === 'date') return get(store, dateKey).then((r) => (r ? [r] : []));
    return byIndex(store, 'date', dateKey);
  }

  function byDateRange(store, from, to) {
    const def = S.STORES[store];
    return byRange(store, def.keyPath === 'date' ? null : 'date', from, to);
  }

  /**
   * Run several writes as ONE transaction: either everything is saved
   * or nothing is. Used by import/restore so a failure never leaves
   * half-restored data.
   */
  async function atomic(storeNames, work) {
    const db = await open();
    const tx = db.transaction(storeNames, 'readwrite');
    const done = tx2p(tx);
    try {
      work(tx);
    } catch (e) {
      try { tx.abort(); } catch (_) {}
      await done.catch(() => {});
      throw e;
    }
    return done;
  }

  // ----- meta (small key/value settings) -----
  async function getMeta(key) {
    const r = await get('meta', key);
    return r ? r.value : undefined;
  }
  function setMeta(key, value) {
    return put('meta', { key, value });
  }

  // ----- storage protection -----
  async function persist() {
    try {
      if (!navigator.storage || !navigator.storage.persist) return null;
      if (await navigator.storage.persisted()) return true;
      return await navigator.storage.persist();
    } catch (e) { return null; }
  }
  async function isPersisted() {
    try { return navigator.storage && navigator.storage.persisted ? await navigator.storage.persisted() : null; }
    catch (e) { return null; }
  }
  async function estimate() {
    try { return navigator.storage && navigator.storage.estimate ? await navigator.storage.estimate() : null; }
    catch (e) { return null; }
  }

  return {
    open, get, getAll, put, putMany, remove, count,
    byIndex, byRange, byDate, byDateRange, atomic,
    getMeta, setMeta, persist, isPersisted, estimate
  };
})();
