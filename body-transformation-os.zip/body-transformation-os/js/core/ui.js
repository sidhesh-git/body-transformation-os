/*
 * ui.js: shared building blocks for every screen:
 * toasts (small messages), bottom sheets (pop-up panels),
 * confirmations, banners, progress bars and empty states.
 */
App.ui = (function () {
  const esc = App.util.esc;

  // ---------- Toast ----------
  function toast(message, type) {
    const box = document.getElementById('toasts');
    if (!box) return;
    const t = document.createElement('div');
    t.className = 'toast' + (type === 'error' ? ' error' : '');
    t.textContent = message;
    box.appendChild(t);
    setTimeout(() => t.remove(), type === 'error' ? 5000 : 2600);
  }

  // ---------- Banner (top of page) ----------
  function banner(message, opts) {
    const o = opts || {};
    const area = document.getElementById('banner-area');
    if (!area) return null;
    if (o.id) {
      const old = area.querySelector('[data-banner="' + o.id + '"]');
      if (old) old.remove();
    }
    const b = document.createElement('div');
    b.className = 'banner' + (o.warn ? ' warn' : '');
    if (o.id) b.dataset.banner = o.id;
    b.innerHTML = '<p>' + esc(message) + '</p>' +
      (o.action ? '<button class="btn btn-primary" type="button">' + esc(o.action) + '</button>' : '') +
      (o.dismiss !== false ? '<button class="icon-btn" type="button" aria-label="Dismiss"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button>' : '');
    const [actionBtn] = b.querySelectorAll('.btn');
    if (actionBtn && o.onAction) actionBtn.addEventListener('click', () => o.onAction(b));
    const close = b.querySelector('.icon-btn');
    if (close) close.addEventListener('click', () => { b.remove(); if (o.onDismiss) o.onDismiss(); });
    area.appendChild(b);
    return b;
  }

  // ---------- Bottom sheet ----------
  /**
   * sheet({ title, html, onOpen(el, close) })
   * Returns a Promise that resolves with the value passed to close(value).
   */
  function sheet(opts) {
    return new Promise((resolve) => {
      const d = document.createElement('dialog');
      d.className = 'sheet';
      d.innerHTML =
        '<div class="sheet-inner">' +
          '<div class="sheet-grip" aria-hidden="true"></div>' +
          (opts.title ? '<h2 class="sheet-title">' + esc(opts.title) + '</h2>' : '') +
          '<div class="sheet-content">' + (opts.html || '') + '</div>' +
        '</div>';
      document.body.appendChild(d);
      let result;
      const close = (value) => { result = value; if (d.open) d.close(); };
      d.addEventListener('close', () => { d.remove(); resolve(result); });
      d.addEventListener('click', (e) => { if (e.target === d) close(undefined); });
      d.showModal();
      if (opts.onOpen) opts.onOpen(d, close);
    });
  }

  // ---------- Confirmation ----------
  /**
   * confirm({ title, message, confirmLabel, cancelLabel, danger, typeToConfirm })
   * typeToConfirm: a word the user must type (e.g. "DELETE") for big actions.
   * Resolves true/false.
   */
  function confirm(o) {
    const needWord = o.typeToConfirm;
    const html =
      '<div class="sheet-body">' + (o.messageHtml || '<p>' + esc(o.message || '') + '</p>') + '</div>' +
      (needWord ? '<div class="field" style="margin-top:16px"><label for="confirm-word">Type ' + esc(needWord) + ' to confirm</label>' +
        '<input class="input" id="confirm-word" autocomplete="off" autocapitalize="characters" spellcheck="false"></div>' : '') +
      '<div class="sheet-actions">' +
        '<button class="btn" type="button" data-act="cancel">' + esc(o.cancelLabel || 'Cancel') + '</button>' +
        '<button class="btn ' + (o.danger ? 'btn-danger-solid' : 'btn-primary') + '" type="button" data-act="ok"' + (needWord ? ' disabled' : '') + '>' +
          esc(o.confirmLabel || 'Confirm') + '</button>' +
      '</div>';
    return sheet({
      title: o.title,
      html,
      onOpen(d, close) {
        const ok = d.querySelector('[data-act="ok"]');
        d.querySelector('[data-act="cancel"]').addEventListener('click', () => close(false));
        ok.addEventListener('click', () => close(true));
        if (needWord) {
          const inp = d.querySelector('#confirm-word');
          inp.addEventListener('input', () => { ok.disabled = inp.value.trim().toUpperCase() !== needWord; });
        } else {
          d.querySelector('[data-act="cancel"]').focus();
        }
      }
    }).then((v) => v === true);
  }

  // ---------- HTML helpers ----------
  function progress(value, target) {
    const pct = (Number.isFinite(value) && target > 0) ? Math.max(0, Math.min(100, (value / target) * 100)) : 0;
    return '<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + Math.round(pct) + '">' +
      '<div class="bar-fill" style="width:' + pct.toFixed(1) + '%"></div></div>';
  }

  function empty(o) {
    return '<div class="empty' + (o.compact ? ' compact' : '') + '">' +
      (o.compact ? '' : '<div class="empty-mark" aria-hidden="true"><i></i><i></i><i></i></div>') +
      '<h3>' + esc(o.title) + '</h3>' +
      (o.text ? '<p>' + esc(o.text) + '</p>' : '') +
      (o.badge ? '<span class="coming">' + esc(o.badge) + '</span>' : '') +
      (o.actionHtml || '') +
    '</div>';
  }

  /** Ask the user to pick a file. Resolves with a File or null. */
  function pickFile(accept) {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = accept || '';
      input.style.display = 'none';
      document.body.appendChild(input);
      input.addEventListener('change', () => {
        const f = input.files && input.files[0];
        input.remove();
        resolve(f || null);
      });
      input.click();
    });
  }

  function setTitle(title) {
    const el = document.getElementById('page-title');
    if (el) el.textContent = title;
    document.title = title + ' | Body Transformation OS';
  }

  return { toast, banner, sheet, confirm, progress, empty, pickFile, setTitle };
})();
