/*
 * boot.js: starts the app. Loaded last.
 */
(function () {
  const esc = App.util.esc;

  // ---------- Embedded in Notion (or any other site) ----------
  // Chrome keeps storage inside an embed separate from the real app,
  // so we show a launcher that opens the real app instead of an empty copy.
  function showLauncher() {
    const base = location.origin + location.pathname;
    const links = [
      { label: 'Open dashboard', hash: '#/dashboard', cls: 'm-protein' },
      { label: 'Log workout',    hash: '#/workout',   cls: 'm-protein' },
      { label: 'Log food',       hash: '#/nutrition', cls: 'm-kcal' },
      { label: 'Log weight',     hash: '#/body',      cls: 'm-weight' }
    ];
    const el = document.getElementById('launcher');
    el.innerHTML =
      '<img src="icons/icon-192.png" alt="" width="64" height="64">' +
      '<h1>Body Transformation OS</h1>' +
      '<p>Your data lives in the app itself, so it opens in a separate tab.</p>' +
      '<div class="quick-grid">' +
        links.map((l) => '<a class="quick ' + l.cls + '" href="' + esc(base + l.hash) + '" target="_blank" rel="noopener">' +
          '<span class="quick-dot" aria-hidden="true"></span>' + esc(l.label) + '</a>').join('') +
      '</div>';
    el.hidden = false;
    document.getElementById('app').hidden = true;
  }

  function fatal(message) {
    document.getElementById('view').innerHTML = App.ui.empty({
      title: 'The app couldn’t start',
      text: message,
      actionHtml: '<button class="btn btn-primary" type="button" onclick="location.reload()">Try again</button>'
    });
  }

  // ---------- Date in the header, and midnight rollover ----------
  let shownDay = null;
  function tickDate() {
    const today = App.dates.today();
    if (today === shownDay) return;
    const first = shownDay === null;
    shownDay = today;
    document.getElementById('page-date').textContent = App.dates.formatLong(today);
    if (!first && App.router.current === 'dashboard') App.router.refresh();
  }

  // ---------- Theme toggle ----------
  function bindThemeToggle() {
    document.getElementById('theme-toggle').addEventListener('click', async () => {
      const t = App.settings.get().theme;
      const isDark = t === 'dark' || (t === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
      await App.settings.update({ theme: isDark ? 'light' : 'dark' });
      if (App.router.current === 'settings') App.router.refresh();
    });
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => App.settings.applyTheme());
  }

  // ---------- Quick-log button ----------
  function bindFab() {
    document.getElementById('fab').addEventListener('click', () => {
      App.ui.sheet({
        title: 'Quick log',
        html: '<div class="sheet-list">' + App.features.dashboard.quickLinks() + '</div>',
        onOpen(d, close) {
          d.querySelectorAll('a').forEach((a) => a.addEventListener('click', () => close()));
        }
      });
    });
  }

  // ---------- Install prompt (Android Chrome) ----------
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    App.installPrompt = e;
    if (App.router.current === 'settings') App.router.refresh();
  });
  window.addEventListener('appinstalled', () => {
    App.installPrompt = null;
    App.ui.toast('Installed. Open it from your home screen.');
    App.db.persist();
  });

  // ---------- Service worker (offline + updates) ----------
  function registerServiceWorker() {
    const secure = location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1';
    if (!('serviceWorker' in navigator) || !secure) {
      App.checkForUpdate = () => App.ui.toast('Updates work once the app is online (GitHub Pages).');
      return;
    }
    let reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => {
      if (reloading) return;
      reloading = true;
      location.reload();
    });

    navigator.serviceWorker.register('service-worker.js').then((reg) => {
      const offerUpdate = () => {
        App.ui.banner('A new version of the app is ready.', {
          id: 'update',
          action: 'Update now',
          onAction: () => { if (reg.waiting) reg.waiting.postMessage('SKIP_WAITING'); }
        });
      };
      if (reg.waiting && navigator.serviceWorker.controller) offerUpdate();
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        if (!w) return;
        w.addEventListener('statechange', () => {
          if (w.state !== 'installed') return;
          if (navigator.serviceWorker.controller) offerUpdate();
          else App.ui.toast('Ready to work offline');
        });
      });
      App.checkForUpdate = async (manual) => {
        try {
          await reg.update();
          if (manual) setTimeout(() => {
            if (!reg.waiting && !reg.installing) App.ui.toast('You have the latest version');
          }, 1500);
        } catch (e) {
          if (manual) App.ui.toast('Couldn’t check for updates. Are you online?', 'error');
        }
      };
      // Check for updates when the app is reopened
      document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') reg.update().catch(() => {});
      });
    }).catch((e) => console.warn('Service worker not registered', e));
  }

  // ---------- Start ----------
  async function start() {
    const params = new URLSearchParams(location.search);
    if (App.util.isEmbedded() && params.get('full') !== '1') {
      showLauncher();
      return;
    }
    try {
      await App.db.open();
      await App.settings.load();
    } catch (e) {
      console.error(e);
      fatal(e && e.message ? e.message : 'Storage is unavailable in this browser.');
      return;
    }
    App.db.persist(); // ask Chrome to keep data safe (silent)
    tickDate();
    setInterval(tickDate, 60 * 1000);
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') tickDate(); });
    bindThemeToggle();
    bindFab();
    await App.router.start();
    App.backup.checkReminder();
    registerServiceWorker();
  }

  window.addEventListener('error', (e) => console.error('App error:', e.error || e.message));
  window.addEventListener('unhandledrejection', (e) => {
    console.error('App error:', e.reason);
    App.ui.toast('Something went wrong. Your saved data is safe.', 'error');
  });

  start();
})();
