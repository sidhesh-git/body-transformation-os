/*
 * placeholders.js: temporary screens for sections built in later phases.
 * Each one only appears if the real screen hasn't been added yet,
 * so later phases never need to edit this file.
 * Must be loaded AFTER all real feature files.
 */
(function () {
  const PLANNED = [
    { name: 'nutrition', title: 'Nutrition', phase: 2,
      heading: 'Food logging is on the way',
      text: 'Log meals, reuse saved meals like “Chicken rice bowl”, and track calories, protein, carbs, fat, fibre and water. Includes common Indian foods you can edit.' },
    { name: 'workout', title: 'Workout', phase: 3,
      heading: 'Workout logging is on the way',
      text: 'Log sets in seconds, see what you lifted last time, get a suggested next target, and have volume and personal records worked out for you.' },
    { name: 'body', title: 'Body', phase: 4,
      heading: 'Body tracking is on the way',
      text: 'Log weight and measurements. Trends use 7-day and 30-day averages so daily ups and downs don’t mislead you.' },
    { name: 'activity', title: 'Activity', phase: 4,
      heading: 'Activity and recovery are on the way',
      text: 'Log steps, walks, runs, cycling and table tennis, plus sleep, energy and soreness.' },
    { name: 'analytics', title: 'Analytics', phase: 5,
      heading: 'Analytics are on the way',
      text: 'Charts, weekly reviews, muscle-group volume, goals and plain-language observations about your trends.' }
  ];

  PLANNED.forEach((p) => {
    if (App.router.has(p.name)) return;
    App.router.register(p.name, {
      title: p.title,
      async render(el) {
        el.innerHTML = '<section class="panel">' +
          App.ui.empty({
            title: p.heading,
            text: p.text,
            badge: 'Arrives in Phase ' + p.phase,
            actionHtml: '<a class="btn" href="#/settings">Set your targets meanwhile</a>'
          }) +
        '</section>';
      }
    });
  });
})();
