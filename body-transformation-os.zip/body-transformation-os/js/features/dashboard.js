/*
 * dashboard.js: the home screen.
 * Reads whatever data exists and shows today, this week, strength,
 * body trend and quick actions. Cards follow your order in Settings.
 *
 * Phase 1: the logging screens don't exist yet, so most values are empty.
 * The calculations below already work and will fill in automatically
 * once later phases add data.
 */
(function () {
  const U = App.util;
  const D = App.dates;
  const esc = U.esc;

  // ---------- data ----------
  async function loadData() {
    const today = D.today();
    const s = App.settings.get();
    const weekStart = D.weekStartOf(today, s.weekStart);
    const prevWeekStart = D.addDays(weekStart, -7);
    const from = D.addDays(today, -104); // enough for 90-day comparisons

    const [food, water, daily, workouts, body] = await Promise.all([
      App.db.byDateRange('foodLog', prevWeekStart, today),
      App.db.byDate('waterLog', today),
      App.db.byDateRange('daily', prevWeekStart, today),
      App.db.byDateRange('workouts', prevWeekStart, today),
      App.db.byDateRange('bodyLog', from, today)
    ]);
    const latestWeight = await findLatestWeight(body);
    return { today, weekStart, prevWeekStart, food, water, daily, workouts, body, latestWeight };
  }

  async function findLatestWeight(recent) {
    let list = recent.filter((r) => Number.isFinite(r.weight));
    if (!list.length) list = (await App.db.getAll('bodyLog')).filter((r) => Number.isFinite(r.weight));
    if (!list.length) return null;
    list.sort((a, b) => (a.date < b.date ? 1 : a.date > b.date ? -1 : (a.updatedAt < b.updatedAt ? 1 : -1)));
    return list[0];
  }

  /** Per-day totals for food */
  function foodByDay(food) {
    const days = {};
    for (const f of food) {
      const d = days[f.date] || (days[f.date] = { kcal: 0, protein: 0 });
      d.kcal += Number.isFinite(f.kcal) ? f.kcal : 0;
      d.protein += Number.isFinite(f.protein) ? f.protein : 0;
    }
    return days;
  }

  function inRange(key, from, to) { return key >= from && key <= to; }

  /** Average weight in [from, to], or null */
  function avgWeight(body, from, to) {
    return U.avg(body.filter((r) => inRange(r.date, from, to)).map((r) => r.weight));
  }

  // ---------- cards ----------
  function tile(o) {
    return '<a class="tile ' + o.cls + '" href="' + o.href + '">' +
      '<span class="tile-label">' + esc(o.label) + '</span>' +
      '<span class="tile-value' + (o.empty ? ' is-empty' : '') + (o.word ? ' is-word' : '') + '">' + o.value +
        (o.unit ? '<span class="unit">' + esc(o.unit) + '</span>' : '') + '</span>' +
      (o.target != null ? App.ui.progress(o.raw, o.target) : '') +
      '<span class="tile-sub">' + esc(o.sub || '') + '</span>' +
    '</a>';
  }

  function cardToday(d) {
    const s = App.settings.get();
    const t = s.targets;
    const days = foodByDay(d.food);
    const todayFood = days[d.today] || { kcal: 0, protein: 0 };
    const waterMl = U.sum(d.water.map((w) => w.ml));
    const dayLog = d.daily.find((x) => x.date === d.today) || {};
    const steps = Number.isFinite(dayLog.steps) ? dayLog.steps : 0;
    const todaysWorkouts = d.workouts.filter((w) => w.date === d.today);
    const done = todaysWorkouts.some((w) => w.status === 'completed');
    const active = todaysWorkouts.some((w) => w.status === 'in-progress');

    const w = d.latestWeight;
    const wUnit = App.units.weightUnit();

    let workoutValue = 'Not yet', workoutSub = 'No session logged today';
    if (done) { workoutValue = 'Done'; workoutSub = todaysWorkouts.length + ' session' + (todaysWorkouts.length > 1 ? 's' : '') + ' today'; }
    else if (active) { workoutValue = 'Active'; workoutSub = 'Workout in progress'; }
    else if (dayLog.restDay) { workoutValue = 'Rest'; workoutSub = 'Planned rest day'; }

    return '<section class="dash-today" aria-labelledby="h-today">' +
      '<h2 id="h-today" class="visually-hidden">Today</h2>' +
      '<div class="tiles">' +
        tile({ cls: 'm-weight', href: '#/body', label: 'Weight',
               value: w ? App.units.formatWeight(w.weight) : '—', unit: w ? wUnit : '', empty: !w,
               sub: !w ? 'No weigh-ins yet' : (w.date === d.today ? 'Weighed today' : 'Last: ' + D.formatShort(w.date)) }) +
        tile({ cls: 'm-kcal', href: '#/nutrition', label: 'Calories',
               value: U.fmt(Math.round(todayFood.kcal)), raw: todayFood.kcal, target: t.kcal, empty: !todayFood.kcal,
               sub: 'of ' + U.fmt(t.kcal) + ' kcal' }) +
        tile({ cls: 'm-protein', href: '#/nutrition', label: 'Protein',
               value: U.fmt(Math.round(todayFood.protein)), unit: 'g', raw: todayFood.protein, target: t.protein, empty: !todayFood.protein,
               sub: 'of ' + U.fmt(t.protein) + ' g' }) +
        tile({ cls: 'm-steps', href: '#/activity', label: 'Steps',
               value: U.fmt(steps), raw: steps, target: t.steps, empty: !steps,
               sub: 'of ' + U.fmt(t.steps) }) +
        tile({ cls: 'm-water', href: '#/nutrition', label: 'Water',
               value: waterMl ? App.units.formatLitres(waterMl) : '0', unit: 'L', raw: waterMl, target: t.waterMl, empty: !waterMl,
               sub: 'of ' + App.units.formatLitres(t.waterMl) + ' L' }) +
        tile({ cls: 'm-workout', href: '#/workout', label: 'Workout',
               value: workoutValue, word: true, empty: !done && !active, sub: workoutSub }) +
      '</div>' +
    '</section>';
  }

  function row(label, value, empty) {
    return '<li class="row"><span class="row-label">' + esc(label) + '</span>' +
      '<span class="row-value' + (empty ? ' is-empty' : '') + '">' + value + '</span></li>';
  }

  function cardWeek(d) {
    const weekDays = (x) => inRange(x.date, d.weekStart, d.today);
    const days = foodByDay(d.food.filter(weekDays));
    const loggedDays = Object.values(days);
    const avgKcal = U.avg(loggedDays.map((x) => x.kcal));
    const avgProtein = U.avg(loggedDays.map((x) => x.protein));
    const dailyWeek = d.daily.filter(weekDays);
    const avgSteps = U.avg(dailyWeek.map((x) => x.steps));
    const avgSleep = U.avg(dailyWeek.map((x) => x.sleepHours));
    const sessions = d.workouts.filter((w) => weekDays(w) && w.status === 'completed').length;

    const thisAvg = avgWeight(d.body, d.weekStart, d.today);
    const lastAvg = avgWeight(d.body, d.prevWeekStart, D.addDays(d.weekStart, -1));
    const wu = App.units.weightUnit();
    let change = '—', changeEmpty = true;
    if (thisAvg != null && lastAvg != null) {
      const diff = App.units.kgToDisplay(thisAvg) - App.units.kgToDisplay(lastAvg);
      change = (diff > 0 ? '+' : diff < 0 ? '−' : '') + U.fmt(Math.abs(diff), 1) + ' ' + wu;
      changeEmpty = false;
    }

    const hasAny = thisAvg != null || avgKcal != null || avgSteps != null || sessions || avgSleep != null;

    return '<section class="panel" aria-labelledby="h-week">' +
      '<div class="panel-head"><h2 id="h-week">This week</h2>' +
        '<span class="muted small">Since ' + esc(D.formatShort(d.weekStart)) + '</span></div>' +
      (hasAny ? '' : '<p class="muted small" style="margin-bottom:6px">Weekly averages appear as you log.</p>') +
      '<ul class="rows">' +
        row('Average weight', thisAvg != null ? App.units.formatWeight(thisAvg) + ' ' + wu : '—', thisAvg == null) +
        row('Change vs last week', change, changeEmpty) +
        row('Average calories', avgKcal != null ? U.fmt(Math.round(avgKcal)) + ' kcal' : '—', avgKcal == null) +
        row('Average protein', avgProtein != null ? U.fmt(Math.round(avgProtein)) + ' g' : '—', avgProtein == null) +
        row('Average steps', avgSteps != null ? U.fmt(Math.round(avgSteps)) : '—', avgSteps == null) +
        row('Workout sessions', String(sessions), !sessions) +
        row('Average sleep', avgSleep != null ? U.fmt(avgSleep, 1) + ' h' : '—', avgSleep == null) +
      '</ul>' +
      (hasAny ? '<p class="panel-note">Averages use only days you logged.</p>' : '') +
    '</section>';
  }

  function cardStrength() {
    return '<section class="panel" aria-labelledby="h-strength">' +
      '<div class="panel-head"><h2 id="h-strength">Strength trend</h2></div>' +
      App.ui.empty({
        compact: true,
        title: 'No lifts logged yet',
        text: 'Once you log workouts, your main lifts show here with an up, down or steady arrow.',
        badge: 'Workout logging arrives in Phase 3'
      }) +
    '</section>';
  }

  function cardBody(d) {
    const weights = d.body.filter((r) => Number.isFinite(r.weight));
    const wu = App.units.weightUnit();
    let content;
    if (weights.length < 2) {
      content = App.ui.empty({
        compact: true,
        title: 'Not enough weigh-ins yet',
        text: 'Log your weight a few times a week. Trends compare averages, so one heavy day won’t mislead you.',
        badge: 'Weight logging arrives in Phase 4'
      });
    } else {
      // Compare the latest 7-day average with the 7-day average N days earlier
      const latest7 = avgWeight(d.body, D.addDays(d.today, -6), d.today);
      const change = (n) => {
        const end = D.addDays(d.today, -n);
        const past = avgWeight(d.body, D.addDays(end, -6), end);
        if (latest7 == null || past == null) return { text: 'Need more data', empty: true };
        const diff = App.units.kgToDisplay(latest7) - App.units.kgToDisplay(past);
        return { text: (diff > 0 ? '+' : diff < 0 ? '−' : '') + U.fmt(Math.abs(diff), 1) + ' ' + wu, empty: false };
      };
      const c7 = change(7), c30 = change(30), c90 = change(90);
      content = '<ul class="rows">' +
        row('Last 7 days', c7.text, c7.empty) +
        row('Last 30 days', c30.text, c30.empty) +
        row('Last 90 days', c90.text, c90.empty) +
      '</ul>' +
      '<p class="panel-note">Compares 7-day averages. Daily weight moves with water, salt and food volume, so single days aren’t fat gain or loss.</p>';
    }
    return '<section class="panel" aria-labelledby="h-body">' +
      '<div class="panel-head"><h2 id="h-body">Body trend</h2><a href="#/body">Body</a></div>' +
      content +
    '</section>';
  }

  const QUICK = [
    { label: 'Add food',     href: '#/nutrition?add=food',   cls: 'm-kcal' },
    { label: 'Log saved meal', href: '#/nutrition?add=meal', cls: 'm-kcal' },
    { label: 'Start workout', href: '#/workout?start=1',     cls: 'm-protein' },
    { label: 'Add exercise', href: '#/workout?add=exercise', cls: 'm-protein' },
    { label: 'Add weight',   href: '#/body?add=weight',      cls: 'm-weight' },
    { label: 'Add steps',    href: '#/activity?add=steps',   cls: 'm-steps' },
    { label: 'Add water',    href: '#/nutrition?add=water',  cls: 'm-water' }
  ];

  function quickLinks() {
    return QUICK.map((q) =>
      '<a class="quick ' + q.cls + '" href="' + q.href + '"><span class="quick-dot" aria-hidden="true"></span>' + esc(q.label) + '</a>'
    ).join('');
  }

  function cardQuick() {
    return '<section class="panel" aria-labelledby="h-quick">' +
      '<div class="panel-head"><h2 id="h-quick">Quick actions</h2></div>' +
      '<div class="quick-grid">' + quickLinks() + '</div>' +
    '</section>';
  }

  function welcome() {
    return '<section class="panel">' +
      '<h2>Welcome to your Body OS</h2>' +
      '<p class="muted" style="margin-top:6px">Everything you log stays on this phone. Start by setting your targets, then add this app to your home screen.</p>' +
      '<div class="btn-row" style="margin-top:14px">' +
        '<a class="btn btn-primary" href="#/settings">Set my targets</a>' +
      '</div>' +
    '</section>';
  }

  const CARDS = { today: cardToday, week: cardWeek, strength: cardStrength, body: cardBody, quick: cardQuick };

  App.router.register('dashboard', {
    title: 'Dashboard',
    async render(el) {
      const d = await loadData();
      const hasData = await App.backup.hasAnyData();
      const order = App.settings.get().dashboardCards.filter((c) => c.visible);
      let html = hasData ? '' : welcome();
      html += order.map((c) => (CARDS[c.id] ? CARDS[c.id](d) : '')).join('');
      if (!order.length) {
        html += App.ui.empty({
          title: 'All dashboard cards are hidden',
          text: 'Choose which cards to show in Settings.',
          actionHtml: '<a class="btn btn-primary" href="#/settings">Open Settings</a>'
        });
      }
      el.innerHTML = html;
    }
  });

  // Shared with the quick-log sheet and the Notion launcher
  App.features.dashboard = { QUICK, quickLinks };
})();
