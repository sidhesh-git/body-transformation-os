/*
 * backup.js: export, import (restore) and full reset.
 *
 * Safety rules:
 *  - Imported files are checked record by record. Bad records are skipped,
 *    never allowed to crash the app.
 *  - Restores run as ONE database transaction: all or nothing.
 *  - Destructive actions always ask for confirmation.
 */
App.backup = (function () {
  const S = App.schema;
  const U = App.util;
  const APP_ID = 'body-transformation-os';
  const MAX_FILE_BYTES = 50 * 1024 * 1024;
  const MAX_TEXT = 5000;

  const STORE_LABELS = {
    meta: 'Settings',
    foods: 'Foods',
    mealTemplates: 'Saved meals',
    foodLog: 'Food entries',
    waterLog: 'Water entries',
    exercises: 'Exercises',
    workouts: 'Workouts',
    sets: 'Sets',
    bodyLog: 'Body entries',
    daily: 'Daily logs (steps, sleep)',
    activityLog: 'Activities',
    goals: 'Goals',
    weeklyReviews: 'Weekly reviews'
  };
  const storeNames = () => Object.keys(S.STORES);
  const dataStores = () => storeNames().filter((s) => s !== 'meta');

  // ---------------- EXPORT ----------------
  async function buildExport() {
    const data = {};
    const counts = {};
    for (const name of storeNames()) {
      data[name] = await App.db.getAll(name);
      counts[name] = data[name].length;
    }
    return {
      app: APP_ID,
      schemaVersion: S.SCHEMA_VERSION,
      dbVersion: S.DB_VERSION,
      appVersion: App.VERSION,
      exportedAt: new Date().toISOString(),
      counts,
      data
    };
  }

  function fileName() {
    const d = new Date();
    const t = String(d.getHours()).padStart(2, '0') + String(d.getMinutes()).padStart(2, '0');
    return 'body-os-backup-' + App.dates.today() + '-' + t + '.json';
  }

  async function makeFile() {
    const payload = await buildExport();
    const json = JSON.stringify(payload, null, 1);
    return new File([json], fileName(), { type: 'application/json' });
  }

  async function download() {
    try {
      const file = await makeFile();
      const url = URL.createObjectURL(file);
      const a = document.createElement('a');
      a.href = url;
      a.download = file.name;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 4000);
      await App.db.setMeta('lastBackupAt', new Date().toISOString());
      App.ui.toast('Backup downloaded: ' + file.name);
      clearReminder();
      return true;
    } catch (e) {
      console.error(e);
      App.ui.toast('The backup could not be created. Try again.', 'error');
      return false;
    }
  }

  function canShareFiles() {
    try {
      const probe = new File(['{}'], 'test.json', { type: 'application/json' });
      return !!(navigator.canShare && navigator.canShare({ files: [probe] }));
    } catch (e) { return false; }
  }

  /** Android: send the backup to Google Drive, email, etc. */
  async function share() {
    try {
      const file = await makeFile();
      if (!(navigator.canShare && navigator.canShare({ files: [file] }))) {
        App.ui.toast('Sharing files isn’t supported here. Use Download instead.', 'error');
        return false;
      }
      await navigator.share({ files: [file], title: 'Body OS backup' });
      await App.db.setMeta('lastBackupAt', new Date().toISOString());
      App.ui.toast('Backup shared');
      clearReminder();
      return true;
    } catch (e) {
      if (e && e.name === 'AbortError') return false; // user closed the share menu
      console.error(e);
      App.ui.toast('Sharing failed. Use Download instead.', 'error');
      return false;
    }
  }

  // ---------------- VALIDATION ----------------
  function cleanValue(v, depth) {
    if (depth > 6) return null;
    if (typeof v === 'string') return v.length > MAX_TEXT ? v.slice(0, MAX_TEXT) : v;
    if (typeof v === 'number') return Number.isFinite(v) ? v : null;
    if (typeof v === 'boolean' || v === null) return v;
    if (Array.isArray(v)) return v.slice(0, 500).map((x) => cleanValue(x, depth + 1));
    if (U.isObj(v)) {
      const o = {};
      for (const [k, x] of Object.entries(v)) {
        if (k === '__proto__' || k === 'constructor' || k === 'prototype') continue;
        o[k] = cleanValue(x, depth + 1);
      }
      return o;
    }
    return null; // functions, undefined, etc.
  }

  /** Returns a clean record, or null if it can't be used */
  function cleanRecord(storeName, rec) {
    if (!U.isObj(rec)) return null;
    const def = S.STORES[storeName];
    const r = cleanValue(rec, 0);

    // Unique key
    const key = r[def.keyPath];
    if (def.keyPath === 'id') {
      if (typeof key !== 'string' || !key.trim() || key.length > 100) r.id = U.id();
    } else if (def.keyPath === 'date') {
      if (!App.dates.isKey(key)) return null;
    } else if (def.keyPath === 'key') {
      if (typeof key !== 'string' || !key || key.length > 100) return null;
    }

    // Required date
    if (def.dateField && !App.dates.isKey(r[def.dateField])) return null;

    // Numbers
    for (const f of def.numbers || []) {
      if (!(f in r)) continue;
      const v = r[f];
      if (typeof v === 'number' && Number.isFinite(v)) continue;
      if (typeof v === 'string' && v.trim() !== '' && Number.isFinite(Number(v))) r[f] = Number(v);
      else r[f] = null;
    }

    // Index fields must be valid lookup keys (text or number)
    for (const idx of def.indexes) {
      const v = r[idx];
      if (v !== undefined && typeof v !== 'string' && typeof v !== 'number') delete r[idx];
    }
    if (typeof r.updatedAt !== 'string') r.updatedAt = r.createdAt && typeof r.createdAt === 'string' ? r.createdAt : new Date(0).toISOString();
    if (typeof r.createdAt !== 'string') r.createdAt = r.updatedAt;
    return r;
  }

  /**
   * Check a backup file. Returns { ok, error } or
   * { ok: true, payload, report: [{store, label, valid, skipped}], exportedAt }
   */
  function validate(text) {
    let payload;
    try {
      payload = JSON.parse(text);
    } catch (e) {
      return { ok: false, error: 'This file isn’t a valid backup. It may be damaged or not a .json backup from this app.' };
    }
    if (!U.isObj(payload) || payload.app !== APP_ID || !U.isObj(payload.data)) {
      return { ok: false, error: 'This file isn’t a Body OS backup.' };
    }
    const v = payload.schemaVersion;
    if (!Number.isInteger(v) || v < 1) {
      return { ok: false, error: 'This backup has no valid version number, so it can’t be restored safely.' };
    }
    if (v > S.SCHEMA_VERSION) {
      return { ok: false, error: 'This backup was made by a newer version of the app. Update the app first, then import.' };
    }
    try {
      payload = S.migrateImport(payload);
    } catch (e) {
      return { ok: false, error: 'This backup couldn’t be upgraded to the current format.' };
    }

    const clean = {};
    const report = [];
    for (const name of storeNames()) {
      const list = Array.isArray(payload.data[name]) ? payload.data[name] : [];
      const seen = new Set();
      const good = [];
      let skipped = 0;
      for (const rec of list) {
        const r = cleanRecord(name, rec);
        const k = r && r[S.STORES[name].keyPath];
        if (!r || seen.has(k)) { skipped++; continue; }
        if (name === 'meta' && k === 'settings') r.value = App.settings.sanitise(r.value);
        seen.add(k);
        good.push(r);
      }
      clean[name] = good;
      report.push({ store: name, label: STORE_LABELS[name] || name, valid: good.length, skipped });
    }
    const total = report.filter((r) => r.store !== 'meta').reduce((a, r) => a + r.valid, 0);
    return {
      ok: true,
      data: clean,
      report,
      total,
      exportedAt: typeof payload.exportedAt === 'string' ? payload.exportedAt : null
    };
  }

  // ---------------- IMPORT ----------------
  async function replaceAll(data) {
    const names = storeNames();
    await App.db.atomic(names, (tx) => {
      for (const name of names) {
        const os = tx.objectStore(name);
        os.clear();
        for (const r of data[name]) os.put(r);
      }
    });
  }

  async function mergeIn(data) {
    // Keep current settings; for matching records keep the newest edit.
    const names = dataStores();
    const existing = {};
    for (const name of names) {
      const map = new Map();
      const key = S.STORES[name].keyPath;
      (await App.db.getAll(name)).forEach((r) => map.set(r[key], r));
      existing[name] = map;
    }
    let added = 0, updated = 0, kept = 0;
    await App.db.atomic(names, (tx) => {
      for (const name of names) {
        const os = tx.objectStore(name);
        const key = S.STORES[name].keyPath;
        for (const r of data[name]) {
          const cur = existing[name].get(r[key]);
          if (!cur) { os.put(r); added++; }
          else if ((r.updatedAt || '') > (cur.updatedAt || '')) { os.put(r); updated++; }
          else kept++;
        }
      }
    });
    return { added, updated, kept };
  }

  async function afterDataChange() {
    await App.settings.load();
    App.router.refresh();
  }

  async function importFlow() {
    const file = await App.ui.pickFile('.json,application/json');
    if (!file) return;
    if (file.size > MAX_FILE_BYTES) {
      App.ui.toast('This file is too large to be a backup (over 50 MB).', 'error');
      return;
    }
    let text;
    try { text = await file.text(); }
    catch (e) { App.ui.toast('The file couldn’t be read. Try downloading it again.', 'error'); return; }

    const res = validate(text);
    if (!res.ok) {
      await App.ui.confirm({ title: 'Can’t import this file', message: res.error, confirmLabel: 'OK', cancelLabel: 'Close' });
      return;
    }

    const rows = res.report
      .filter((r) => r.valid || r.skipped)
      .map((r) => '<tr><td>' + U.esc(r.label) + (r.skipped ? ' <span class="error">(' + r.skipped + ' skipped)</span>' : '') +
        '</td><td>' + U.fmt(r.valid) + '</td></tr>').join('');
    const skippedTotal = res.report.reduce((a, r) => a + r.skipped, 0);
    const when = res.exportedAt ? new Date(res.exportedAt).toLocaleString() : 'unknown date';

    const choice = await App.ui.sheet({
      title: 'Import backup',
      html:
        '<div class="sheet-body">' +
          '<p>Backup from <strong>' + U.esc(when) + '</strong>, with ' + U.fmt(res.total) + ' records.</p>' +
          (skippedTotal ? '<p class="error">' + skippedTotal + ' damaged or duplicate records will be skipped.</p>' : '') +
          (rows ? '<table class="summary-table">' + rows + '</table>' : '<p>This backup contains no records.</p>') +
          '<p style="margin-top:14px"><strong>Merge</strong> adds the backup to what’s already here and keeps your current settings. ' +
          'If the same entry exists in both, the most recently edited version is kept.</p>' +
          '<p><strong>Replace</strong> deletes everything currently in the app, then restores the backup exactly.</p>' +
        '</div>' +
        '<div class="sheet-actions">' +
          '<button class="btn" type="button" data-c="cancel">Cancel</button>' +
          '<button class="btn btn-danger" type="button" data-c="replace">Replace all data</button>' +
          '<button class="btn btn-primary" type="button" data-c="merge">Merge</button>' +
        '</div>',
      onOpen(d, close) {
        d.querySelectorAll('[data-c]').forEach((b) => b.addEventListener('click', () => close(b.dataset.c)));
      }
    });

    try {
      if (choice === 'merge') {
        const r = await mergeIn(res.data);
        await afterDataChange();
        App.ui.toast('Merged: ' + r.added + ' added, ' + r.updated + ' updated');
      } else if (choice === 'replace') {
        const sure = await App.ui.confirm({
          title: 'Replace all data?',
          messageHtml: '<p>Everything currently in the app will be deleted and replaced with this backup. This can’t be undone.</p>' +
            '<p>If you’re not sure, cancel and download a backup of your current data first.</p>',
          confirmLabel: 'Replace all data',
          danger: true,
          typeToConfirm: 'REPLACE'
        });
        if (!sure) return;
        await replaceAll(res.data);
        await afterDataChange();
        App.ui.toast('Backup restored');
      }
    } catch (e) {
      console.error(e);
      App.ui.toast('Import failed. Nothing was changed.', 'error');
    }
  }

  // ---------------- RESET ----------------
  async function resetFlow() {
    const step = await App.ui.sheet({
      title: 'Delete all data?',
      html:
        '<div class="sheet-body"><p>This permanently deletes every food, workout, measurement, goal and setting stored in this browser.</p>' +
        '<p>Download a backup first so you can restore it later if needed.</p></div>' +
        '<div class="sheet-actions">' +
          '<button class="btn" type="button" data-c="cancel">Cancel</button>' +
          '<button class="btn btn-danger" type="button" data-c="delete">Delete without backup</button>' +
          '<button class="btn btn-primary" type="button" data-c="backup">Download backup first</button>' +
        '</div>',
      onOpen(d, close) {
        d.querySelectorAll('[data-c]').forEach((b) => b.addEventListener('click', () => close(b.dataset.c)));
      }
    });
    if (!step || step === 'cancel') return;
    if (step === 'backup') {
      const ok = await download();
      if (!ok) return;
    }
    const sure = await App.ui.confirm({
      title: 'Final check',
      message: 'All data in this app will be permanently deleted.',
      confirmLabel: 'Delete everything',
      danger: true,
      typeToConfirm: 'DELETE'
    });
    if (!sure) return;
    try {
      const names = storeNames();
      await App.db.atomic(names, (tx) => names.forEach((n) => tx.objectStore(n).clear()));
      try { localStorage.removeItem('btos-theme'); } catch (e) {}
      await afterDataChange();
      App.ui.toast('All data deleted');
    } catch (e) {
      console.error(e);
      App.ui.toast('Delete failed. Your data was not changed.', 'error');
    }
  }

  // ---------------- REMINDER ----------------
  async function hasAnyData() {
    for (const n of dataStores()) { if (await App.db.count(n)) return true; }
    return false;
  }

  async function lastBackupAt() { return App.db.getMeta('lastBackupAt'); }

  function clearReminder() {
    const b = document.querySelector('[data-banner="backup"]');
    if (b) b.remove();
  }

  async function checkReminder() {
    try {
      if (sessionStorage.getItem('btos-backup-dismissed')) return;
      if (!(await hasAnyData())) return;
      const last = await lastBackupAt();
      const days = last ? (Date.now() - new Date(last).getTime()) / 86400000 : Infinity;
      if (days < 7) return;
      App.ui.banner(last ? 'Last backup was ' + Math.floor(days) + ' days ago.' : 'You haven’t backed up your data yet.', {
        id: 'backup',
        warn: true,
        action: 'Back up',
        onAction: () => download(),
        onDismiss: () => { try { sessionStorage.setItem('btos-backup-dismissed', '1'); } catch (e) {} }
      });
    } catch (e) { /* reminders are optional */ }
  }

  return { download, share, canShareFiles, importFlow, resetFlow, validate, hasAnyData, lastBackupAt, checkReminder, buildExport };
})();
