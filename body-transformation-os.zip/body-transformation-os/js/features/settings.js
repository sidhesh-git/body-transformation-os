/*
 * settings.js: targets, units, theme, dashboard cards,
 * backup/restore, Notion links, and app info.
 */
(function () {
  const U = App.util;
  const esc = U.esc;

  // Target fields: key, label, suffix, limits, whole number?
  const TARGET_FIELDS = [
    { key: 'kcal',       label: 'Calories',  suffix: 'kcal', min: 800,  max: 8000,   integer: true },
    { key: 'protein',    label: 'Protein',   suffix: 'g',    min: 10,   max: 500,    integer: true },
    { key: 'carbs',      label: 'Carbs',     suffix: 'g',    min: 10,   max: 1000,   integer: true },
    { key: 'fat',        label: 'Fat',       suffix: 'g',    min: 10,   max: 400,    integer: true },
    { key: 'fiber',      label: 'Fibre',     suffix: 'g',    min: 5,    max: 150,    integer: true },
    { key: 'waterMl',    label: 'Water',     suffix: 'L',    min: 0.5,  max: 10,     scale: 1000 },
    { key: 'steps',      label: 'Steps',     suffix: 'steps', min: 500, max: 100000, integer: true },
    { key: 'sleepHours', label: 'Sleep',     suffix: 'h',    min: 3,    max: 14 }
  ];

  function field(id, label, value, suffix, hint) {
    return '<div class="field">' +
      '<label for="' + id + '">' + esc(label) + '</label>' +
      '<div class="input-wrap"><input class="input" id="' + id + '" inputmode="decimal" autocomplete="off" value="' + esc(value) + '">' +
      (suffix ? '<span class="suffix">' + esc(suffix) + '</span>' : '') + '</div>' +
      (hint ? '<span class="hint">' + esc(hint) + '</span>' : '') +
      '<span class="error" data-error-for="' + id + '" hidden></span>' +
    '</div>';
  }

  function segmented(name, options, value) {
    return '<div class="segmented" role="group" data-seg="' + name + '">' +
      options.map((o) => '<button type="button" data-value="' + esc(o.value) + '" aria-pressed="' + (String(o.value) === String(value)) + '">' + esc(o.label) + '</button>').join('') +
    '</div>';
  }

  // ---------- panels ----------
  function panelTargets(s) {
    const wu = App.units.weightUnit();
    const goal = s.goalWeightKg != null ? U.round(App.units.kgToDisplay(s.goalWeightKg), 1) : '';
    return '<section class="panel" aria-labelledby="h-targets">' +
      '<div class="panel-head"><h2 id="h-targets">Daily targets</h2></div>' +
      '<div class="form-grid pairs">' +
        TARGET_FIELDS.map((f) => field('t-' + f.key, f.label,
          f.scale ? U.round(s.targets[f.key] / f.scale, 2) : s.targets[f.key], f.suffix)).join('') +
      '</div>' +
      '<div class="form-grid two" style="margin-top:14px">' +
        field('t-maint', 'Maintenance calories (estimate)', s.maintenanceKcal == null ? '' : s.maintenanceKcal, 'kcal',
          'Optional. Your best guess of what you burn per day.') +
        field('t-goal', 'Goal weight', goal, wu, 'Optional.') +
      '</div>' +
      '<p class="hint" id="kcal-note" style="margin-top:10px" hidden></p>' +
      '<div class="btn-row" style="margin-top:16px"><button class="btn btn-primary" type="button" id="save-targets">Save targets</button></div>' +
    '</section>';
  }

  function panelUnits(s) {
    return '<section class="panel" aria-labelledby="h-units">' +
      '<div class="panel-head"><h2 id="h-units">Units and week</h2></div>' +
      '<div class="form-grid">' +
        '<div class="field"><span class="field-label">Weight</span>' + segmented('weightUnit', [{ value: 'kg', label: 'kg' }, { value: 'lb', label: 'lb' }], s.weightUnit) + '</div>' +
        '<div class="field"><span class="field-label">Body measurements</span>' + segmented('lengthUnit', [{ value: 'cm', label: 'cm' }, { value: 'in', label: 'in' }], s.lengthUnit) + '</div>' +
        '<div class="field"><span class="field-label">Distance</span>' + segmented('distanceUnit', [{ value: 'km', label: 'km' }, { value: 'mi', label: 'miles' }], s.distanceUnit) + '</div>' +
        '<div class="field"><span class="field-label">Week starts on</span>' + segmented('weekStart', [{ value: 1, label: 'Monday' }, { value: 0, label: 'Sunday' }], s.weekStart) + '</div>' +
      '</div>' +
      '<p class="panel-note">Changing units only changes how numbers are shown. Saved data isn’t altered.</p>' +
    '</section>';
  }

  function panelTheme(s) {
    return '<section class="panel" aria-labelledby="h-theme">' +
      '<div class="panel-head"><h2 id="h-theme">Appearance</h2></div>' +
      segmented('theme', [{ value: 'system', label: 'Match phone' }, { value: 'light', label: 'Light' }, { value: 'dark', label: 'Dark' }], s.theme) +
    '</section>';
  }

  function panelCards(s) {
    const names = Object.fromEntries(App.settings.DASHBOARD_CARDS.map((c) => [c.id, c.name]));
    const list = s.dashboardCards;
    const up = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 14 6-6 6 6"/></svg>';
    const down = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m6 10 6 6 6-6"/></svg>';
    return '<section class="panel" aria-labelledby="h-cards">' +
      '<div class="panel-head"><h2 id="h-cards">Dashboard cards</h2></div>' +
      list.map((c, i) =>
        '<div class="setting-row">' +
          '<div class="setting-text">' + esc(names[c.id] || c.id) + '</div>' +
          '<div class="setting-actions">' +
            '<button class="icon-btn" type="button" data-move="' + i + '" data-dir="-1" aria-label="Move ' + esc(names[c.id]) + ' up"' + (i === 0 ? ' disabled' : '') + '>' + up + '</button>' +
            '<button class="icon-btn" type="button" data-move="' + i + '" data-dir="1" aria-label="Move ' + esc(names[c.id]) + ' down"' + (i === list.length - 1 ? ' disabled' : '') + '>' + down + '</button>' +
            '<label class="switch"><input type="checkbox" data-card="' + esc(c.id) + '"' + (c.visible ? ' checked' : '') + ' aria-label="Show ' + esc(names[c.id]) + '"><span></span></label>' +
          '</div>' +
        '</div>'
      ).join('') +
    '</section>';
  }

  async function panelData() {
    const last = await App.backup.lastBackupAt();
    const persisted = await App.db.isPersisted();
    const est = await App.db.estimate();
    const lastText = last ? new Date(last).toLocaleString() : 'Never';
    const used = est && Number.isFinite(est.usage) ? (est.usage / 1024 / 1024).toFixed(1) + ' MB used' : '';
    let protectText = 'Unknown in this browser';
    if (persisted === true) protectText = 'Protected. Chrome won’t clear it automatically.';
    else if (persisted === false) protectText = 'Not yet protected. Installing the app to your home screen usually fixes this.';

    return '<section class="panel" aria-labelledby="h-data">' +
      '<div class="panel-head"><h2 id="h-data">Backup and data</h2></div>' +
      '<ul class="rows">' +
        '<li class="row"><span class="row-label">Last backup</span><span class="small">' + esc(lastText) + '</span></li>' +
        '<li class="row"><span class="row-label">Storage</span><span class="small" style="text-align:right">' + esc(protectText) + (used ? '<br>' + esc(used) : '') + '</span></li>' +
      '</ul>' +
      '<p class="panel-note">Your data is stored only in this browser on this device. Back up regularly and keep the file somewhere safe, such as Google Drive.</p>' +
      '<div class="form-grid" style="margin-top:14px">' +
        '<button class="btn btn-primary btn-block" type="button" id="do-export">Download backup</button>' +
        (App.backup.canShareFiles() ? '<button class="btn btn-block" type="button" id="do-share">Share backup to Drive or email</button>' : '') +
        '<button class="btn btn-block" type="button" id="do-import">Import backup</button>' +
        (persisted === false ? '<button class="btn btn-block" type="button" id="do-persist">Ask Chrome to protect my data</button>' : '') +
        '<button class="btn btn-danger btn-block" type="button" id="do-reset">Delete all data</button>' +
      '</div>' +
    '</section>';
  }

  function appUrl(hash) {
    return location.origin + location.pathname + (hash || '');
  }

  function panelLinks() {
    const links = [
      { label: 'Dashboard', hash: '#/dashboard' },
      { label: 'Workout', hash: '#/workout' },
      { label: 'Nutrition', hash: '#/nutrition' },
      { label: 'Body', hash: '#/body' }
    ];
    const standalone = window.matchMedia('(display-mode: standalone)').matches;
    const isWeb = location.protocol === 'https:' || location.hostname === 'localhost';
    return '<section class="panel" aria-labelledby="h-links">' +
      '<div class="panel-head"><h2 id="h-links">Home screen and Notion</h2></div>' +
      (standalone
        ? '<p class="muted">You’re using the installed app.</p>'
        : (App.installPrompt
            ? '<button class="btn btn-primary btn-block" type="button" id="do-install">Install app on this device</button>'
            : '<p class="muted small">To install: open this page in Chrome, tap the ⋮ menu, then choose <strong>Add to Home screen</strong> or <strong>Install app</strong>.</p>')) +
      (isWeb
        ? '<p class="panel-note">Paste these links into Notion. Each opens that screen directly.</p>' +
          '<ul class="rows">' + links.map((l) =>
            '<li class="row" style="align-items:center"><span class="row-label">' + esc(l.label) + '</span>' +
            '<button class="link-btn" type="button" data-copy="' + esc(appUrl(l.hash)) + '">Copy link</button></li>').join('') +
          '</ul>'
        : '<p class="panel-note">Links for Notion appear here once the app is online (after you publish it on GitHub Pages).</p>') +
    '</section>';
  }

  function panelAbout() {
    return '<section class="panel" aria-labelledby="h-about">' +
      '<div class="panel-head"><h2 id="h-about">About</h2></div>' +
      '<ul class="rows">' +
        '<li class="row"><span class="row-label">Version</span><span class="small">' + esc(App.VERSION) + ' (Phase ' + App.PHASE + ')</span></li>' +
        '<li class="row"><span class="row-label">Data format</span><span class="small">v' + App.schema.SCHEMA_VERSION + '</span></li>' +
      '</ul>' +
      '<p class="panel-note">No accounts, trackers or ads. Nothing you log is sent anywhere.</p>' +
      '<div class="btn-row" style="margin-top:12px"><button class="btn" type="button" id="do-update">Check for updates</button></div>' +
    '</section>';
  }

  // ---------- behaviour ----------
  function showError(el, id, msg) {
    const input = el.querySelector('#' + id);
    const err = el.querySelector('[data-error-for="' + id + '"]');
    if (input) input.setAttribute('aria-invalid', msg ? 'true' : 'false');
    if (err) { err.textContent = msg || ''; err.hidden = !msg; }
  }

  function kcalNote(el) {
    const note = el.querySelector('#kcal-note');
    const r = App.units.parseNum(el.querySelector('#t-kcal').value, {});
    const m = App.units.parseNum(el.querySelector('#t-maint').value, {});
    let msg = '';
    if (r.ok && r.value && r.value < 1500) {
      msg = 'This is a low calorie target. Very low intakes are hard to sustain and can cost muscle. Consider checking it with a doctor or dietitian.';
    } else if (r.ok && m.ok && r.value && m.value && m.value - r.value > 1000) {
      msg = 'This target is over 1,000 kcal below your maintenance estimate. A smaller deficit is usually easier to keep up while training.';
    }
    note.textContent = msg;
    note.hidden = !msg;
  }

  async function saveTargets(el) {
    const targets = {};
    let ok = true;
    for (const f of TARGET_FIELDS) {
      const id = 't-' + f.key;
      const r = App.units.parseNum(el.querySelector('#' + id).value, { required: true, min: f.min, max: f.max, integer: f.integer, label: f.label });
      showError(el, id, r.ok ? '' : r.error);
      if (!r.ok) { ok = false; continue; }
      targets[f.key] = f.scale ? Math.round(r.value * f.scale) : r.value;
    }
    const m = App.units.parseNum(el.querySelector('#t-maint').value, { min: 1000, max: 8000, integer: true, label: 'Maintenance' });
    showError(el, 't-maint', m.ok ? '' : m.error);
    if (!m.ok) ok = false;

    const wu = App.units.weightUnit();
    const g = App.units.parseNum(el.querySelector('#t-goal').value, {
      min: wu === 'kg' ? 30 : 66, max: wu === 'kg' ? 300 : 660, label: 'Goal weight'
    });
    showError(el, 't-goal', g.ok ? '' : g.error);
    if (!g.ok) ok = false;

    if (!ok) {
      App.ui.toast('Fix the highlighted fields.', 'error');
      const bad = el.querySelector('[aria-invalid="true"]');
      if (bad) bad.focus();
      return;
    }
    const goalKg = g.value == null ? null : U.round(App.units.displayToKg(g.value), 2);
    await App.settings.update({ targets, maintenanceKcal: m.value, goalWeightKg: goalKg });
    App.ui.toast('Targets saved');
  }

  async function copy(text) {
    try {
      await navigator.clipboard.writeText(text);
      App.ui.toast('Link copied');
    } catch (e) {
      await App.ui.sheet({
        title: 'Copy this link',
        html: '<p class="url-box">' + esc(text) + '</p><p class="hint" style="margin-top:8px">Press and hold the link to copy it.</p>'
      });
    }
  }

  function bind(el) {
    // Targets
    el.querySelector('#save-targets').addEventListener('click', () => saveTargets(el));
    ['#t-kcal', '#t-maint'].forEach((sel) => el.querySelector(sel).addEventListener('input', () => kcalNote(el)));
    kcalNote(el);

    // Segmented controls (auto-save)
    el.querySelectorAll('[data-seg]').forEach((group) => {
      group.addEventListener('click', async (e) => {
        const btn = e.target.closest('button[data-value]');
        if (!btn) return;
        const key = group.dataset.seg;
        let value = btn.dataset.value;
        if (key === 'weekStart') value = Number(value);
        await App.settings.update({ [key]: value });
        App.ui.toast('Saved');
        App.router.refresh();
      });
    });

    // Dashboard cards
    el.querySelectorAll('[data-card]').forEach((cb) => {
      cb.addEventListener('change', async () => {
        const cards = App.settings.get().dashboardCards.map((c) => c.id === cb.dataset.card ? { id: c.id, visible: cb.checked } : c);
        await App.settings.update({ dashboardCards: cards });
        App.ui.toast(cb.checked ? 'Card shown' : 'Card hidden');
      });
    });
    el.querySelectorAll('[data-move]').forEach((b) => {
      b.addEventListener('click', async () => {
        const i = Number(b.dataset.move), dir = Number(b.dataset.dir);
        const cards = App.settings.get().dashboardCards.slice();
        const j = i + dir;
        if (j < 0 || j >= cards.length) return;
        [cards[i], cards[j]] = [cards[j], cards[i]];
        await App.settings.update({ dashboardCards: cards });
        App.router.refresh();
      });
    });

    // Data
    el.querySelector('#do-export').addEventListener('click', async () => { await App.backup.download(); App.router.refresh(); });
    const share = el.querySelector('#do-share');
    if (share) share.addEventListener('click', async () => { if (await App.backup.share()) App.router.refresh(); });
    el.querySelector('#do-import').addEventListener('click', () => App.backup.importFlow());
    el.querySelector('#do-reset').addEventListener('click', () => App.backup.resetFlow());
    const persist = el.querySelector('#do-persist');
    if (persist) persist.addEventListener('click', async () => {
      const ok = await App.db.persist();
      App.ui.toast(ok ? 'Chrome will now protect your data' : 'Chrome said no for now. Install the app to your home screen and try again.', ok ? '' : 'error');
      App.router.refresh();
    });

    // Install + links
    const install = el.querySelector('#do-install');
    if (install) install.addEventListener('click', async () => {
      const p = App.installPrompt;
      if (!p) return;
      p.prompt();
      try { await p.userChoice; } catch (e) {}
      App.installPrompt = null;
      App.router.refresh();
    });
    el.querySelectorAll('[data-copy]').forEach((b) => b.addEventListener('click', () => copy(b.dataset.copy)));

    // Updates
    el.querySelector('#do-update').addEventListener('click', () => App.checkForUpdate && App.checkForUpdate(true));
  }

  App.router.register('settings', {
    title: 'Settings',
    async render(el) {
      const s = App.settings.get();
      el.innerHTML =
        panelTargets(s) +
        panelUnits(s) +
        panelTheme(s) +
        panelCards(s) +
        (await panelData()) +
        panelLinks() +
        panelAbout();
      bind(el);
    }
  });
})();
