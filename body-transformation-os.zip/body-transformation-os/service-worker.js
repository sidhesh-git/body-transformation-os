/*
 * Service worker: makes the app work offline.
 *
 * HOW UPDATES WORK
 * Every time the app's files change, CACHE_VERSION below must change too.
 * (Each phase I send you will already have a new number.)
 * The app then shows "Update available — Reload" instead of silently
 * mixing old and new files.
 *
 * This file never touches your data. Data lives in IndexedDB, not in this cache.
 */

const CACHE_VERSION = 'btos-v1.0.0';

const FILES = [
  './',
  './index.html',
  './manifest.json',
  './css/base.css',
  './css/layout.css',
  './css/components.css',
  './fonts/barlow-condensed-600.woff2',
  './fonts/barlow-condensed-700.woff2',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/icon-maskable-512.png',
  './icons/apple-touch-icon.png',
  './js/core/app.js',
  './js/core/dates.js',
  './js/core/units.js',
  './js/core/migrations.js',
  './js/core/db.js',
  './js/core/settings-store.js',
  './js/core/ui.js',
  './js/core/router.js',
  './js/core/boot.js',
  './js/features/backup.js',
  './js/features/dashboard.js',
  './js/features/settings.js',
  './js/features/placeholders.js'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) =>
      // Fetch fresh copies (bypass the browser's HTTP cache)
      cache.addAll(FILES.map((f) => new Request(f, { cache: 'reload' })))
    )
  );
  // Do NOT skipWaiting automatically. The page asks the user first.
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith('btos-') && k !== CACHE_VERSION).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', (event) => {
  if (event.data === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // never touch other sites

  // Page loads: serve the cached app shell (works offline)
  if (req.mode === 'navigate') {
    event.respondWith(
      caches.match('./index.html', { ignoreSearch: true })
        .then((cached) => cached || fetch(req))
        .catch(() => caches.match('./index.html', { ignoreSearch: true }))
    );
    return;
  }

  // Everything else: cache first, then network
  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        if (res && res.ok && res.type === 'basic') {
          const copy = res.clone();
          caches.open(CACHE_VERSION).then((c) => c.put(req, copy));
        }
        return res;
      });
    })
  );
});
